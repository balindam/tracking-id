const express = require('express');
const mysql = require('mysql');
const crypto = require('crypto');
const app = express();

// Database connection
const db = mysql.createConnection({
  host: '51.89.99.210',
  user: 'movietrck_testTracker',
  password: 'jGV&=qa7@Ed+',
  database: 'movietrck_offer_process'
});

// Generate a 32 character hash
function generateHash() {
  return crypto.randomBytes(16).toString('hex');
}

app.get('/', (req, res) => {
  const user = req.query.pubid;
  const ip = req.ip;

  // Check if user = 2
  if (user != 2) {
    res.send('Invalid Publisher ID.');
    return;
  }

  const hash = generateHash();

  const query = "INSERT INTO `offer_process_nfl`(`hash`, `date`, `pubid`, `ip`) VALUES (?, NOW(), 2, ?)";
  const values = [hash, ip];

  // Insert click into DB
  db.query(query, values, (err, result) => {
    if (err) throw err;
    console.log(values)
    // Hardcoded redirect link with just 1 dynamic value: $hash
    const redirect_link = `https://sportsnlivehd.net/live-football.php?lang=en&promo=stream&flow=trial?subid=2&t1=${hash}`;

    // Redirect
    res.redirect(redirect_link);
  });
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});